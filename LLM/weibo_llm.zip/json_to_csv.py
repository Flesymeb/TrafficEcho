import json
import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer

# 读取 JSON 数据
with open("test.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 提取文本和标签
texts = [item["微博正文"] for item in data]
labels = [item["true_label"] for item in data]

# 进行多标签 one-hot 编码
mlb = MultiLabelBinarizer()
labels_encoded = mlb.fit_transform(labels)

# 创建 DataFrame
df = pd.DataFrame(labels_encoded, columns=mlb.classes_)
df.insert(0, "text", texts)

# 保存为 CSV
df.to_csv("test.csv", index=False, encoding="utf-8")
