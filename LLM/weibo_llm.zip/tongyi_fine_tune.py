import json
import requests
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# 1. 读取数据
def load_data(json_file):
    with open(json_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    texts = [item["微博正文"] for item in data]
    labels = [item["true_label"] for item in data]
    return texts, labels


# 2. 预处理数据
def preprocess_data(texts, labels):
    mlb = MultiLabelBinarizer()
    binarized_labels = mlb.fit_transform(labels)
    return texts, binarized_labels, mlb.classes_


# 3. 发送请求进行微调
def fine_tune_qwen(api_key, train_texts, train_labels):
    url = "https://api.qwen.aliyun.com/v1/fine-tune"
    payload = {
        "model": "qwen-turbo",
        "train_data": [{"text": text, "label": label.tolist()} for text, label in zip(train_texts, train_labels)],
        "epochs": 3
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    response = requests.post(url, headers=headers, json=payload)
    return response.json()


# 4. 进行推理
def predict_qwen(api_key, texts):
    url = "https://api.qwen.aliyun.com/v1/predict"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    predictions = []
    for text in texts:
        payload = {"model": "qwen-turbo", "input": text}
        response = requests.post(url, headers=headers, json=payload)
        result = response.json()
        predictions.append(result.get("label", []))
    return predictions


# 5. 评估模型
def evaluate(predictions, true_labels, mlb):
    binarized_preds = mlb.transform(predictions)
    binarized_true = mlb.transform(true_labels)
    accuracy = accuracy_score(binarized_true, binarized_preds)
    report = classification_report(binarized_true, binarized_preds, target_names=mlb.classes_)
    return accuracy, report


if __name__ == "__main__":
    api_key = "sk-24297ab9c2f9472bb17d17ec9e313021"
    json_file = "test.json"

    # 加载和处理数据
    texts, labels = load_data(json_file)
    train_texts, test_texts, train_labels, test_labels = train_test_split(texts, labels, test_size=0.2, random_state=42)
    train_texts, train_labels, class_names = preprocess_data(train_texts, train_labels)
    test_texts, test_labels, _ = preprocess_data(test_texts, test_labels)

    # 发送微调请求
    fine_tune_qwen(api_key, train_texts, train_labels)

    # 模型推理
    predictions = predict_qwen(api_key, test_texts)

    # 评估结果
    accuracy, report = evaluate(predictions, test_labels, MultiLabelBinarizer(classes=class_names))
    print(f"Accuracy: {accuracy}\n")
    print(f"Classification Report:\n{report}")
