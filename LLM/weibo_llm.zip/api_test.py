from openai import OpenAI
import json
import time
from sklearn.metrics import classification_report, hamming_loss, jaccard_score

#client = OpenAI(api_key="sk-7e199537e51e4157b4e26c12ee2b8267", base_url="https://api.deepseek.com")
client = OpenAI(
    # 若没有配置环境变量，请用百炼API Key将下行替换为：api_key="sk-xxx",
    api_key="sk-24297ab9c2f9472bb17d17ec9e313021",
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

# 定义交通评价类别
categories = ["安全性", "运行效率", "可靠性", "舒适性", "便捷性", "信息化与智能化", "经济性", "环境友好性", "社会可持续性"]

# 读取微博数据（假设 JSON 文件格式: [{"text": "微博内容1"}, {"text": "微博内容2"}]）
with open("test.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 定义分类规则（系统提示）
system_prompt = """你是一个专业的交通评价分析师，你的任务是对用户提供的微博内容进行分类。请根据以下交通评价维度进行分类：
1. **安全性（Safety）**：涉及交通事故、乘客安全、运营安全、设施安全、应急响应的就是安全性相关。
2. **运行效率（Operational Efficiency）**：涉及到行程时间、拥堵情况、旅行时间的就是运行效率相关。
3. **可靠性（Reliability）**：涉及到公共交通的准点率、运行时间的稳定性（比如晚点、早点之类的）、服务一致性、线路可靠性、交通事件对运营的影响、维护和保养情况的，就是可靠性相关。
4. **舒适性（Comfort）**：涉及到乘坐舒适度、车厢整洁度、设备情况、通风、温度等的或者其他超出交通出行的最基础服务的，就是舒适性相关。
5. **便捷性（Convenience）**：涉及到交通方式的可获得性、线路或路网的覆盖率、换乘便捷性、票务便利性、出行时间成本（尤其是地铁、公交）、无障碍出行等的，就是便捷性相关。
6. **信息化与智能化（Information & Smart Technology）**：涉及到交通信息的可获取性、实时信息服务、交通系统的智能化程度、乘客与系统之间的交互、交通预测、交通管理与控制方面的，就是信息化与智能化相关。
7. **经济性（Economic Efficiency）**：涉及到花钱、票价、燃油费等关于出行的花费的评价、涉及到运营成本、投资回报率、工程建设费用的就是经济性相关；"
8. **环境友好性（Environmental Friendliness）**：涉及到能源消耗、新能源汽车的优势、排放、对空气质量的影响、绿色出行、交通基础设施建设对环境的影响等的，就是环境友好性相关。
9. **社会可持续性（Social Sustainability）**：涉及到交通公平性、社会福祉、交通对于城市空间的影响、社会服务、社会责任的（个人和公共交通都可以）相关评论，就是社会可持续性相关。
你的任务是按照以上分类标准，对输入的文本进行分类，并返回匹配的类别列表，不要进行额外解释。"""


# 定义大模型分类函数
def classify_text(text):
    prompt = (
        f"请将以下微博文本分类到合适的一个或几个交通评价维度，仅返回分类标签列表，不要解释。\n"
        f"可选类别：{', '.join(categories)}。\n\n"
        f"文本：{text}\n"
        f"请直接返回预测类别列表，格式如：['安全性','运行效率']，不要额外说明。"
    )

    try:
        response = client.chat.completions.create(
            model="qwen-max",  #max>plus>turbo
            messages=[
                {"role": "system","content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            stream=False
        )
        # 解析模型输出
        output_text = response.choices[0].message.content.strip()
        predicted_labels = eval(output_text) if "[" in output_text else [output_text]  # 解析成 Python 列表
        return [label for label in predicted_labels if label in categories]  # 过滤无效标签

    except Exception as e:
        print(f"分类失败: {e}")
        return "分类失败"

# 处理50条数据
results = []
for i, post in enumerate(data[:50]):
    text = post["微博正文"]
    true_label = post.get("true_label", [])  # 真实标签
    predicted_label = classify_text(text)  # 预测标签

    results.append({
        "text": text,
        "true_label": true_label,
        "predicted_label": predicted_label
    })

    print(f"第 {i + 1}/50 条分类完成: {predicted_label}")
    time.sleep(1)  # 避免 API 速率限制

# 保存分类结果
with open("classified_posts_muti_3.json", "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=4)
print("全部分类任务完成，结果已保存到 classified_posts_muti_3.json")

# 加载数据
with open("classified_posts_muti_2.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 将类别转换为二进制向量
def to_binary_vector(labels, category_list):
    return [1 if category in labels else 0 for category in category_list]

y_true = [to_binary_vector(item["true_label"], categories) for item in data]
y_pred = [to_binary_vector(item["predicted_label"], categories) for item in data]

# 计算分类评估指标
print("Hamming Loss:", hamming_loss(y_true, y_pred))  # 越小越好
print("Jaccard Index (average='samples'):", jaccard_score(y_true, y_pred, average='samples'))  # 越接近1越好
print("\nClassification Report:\n", classification_report(y_true, y_pred, target_names=categories))

