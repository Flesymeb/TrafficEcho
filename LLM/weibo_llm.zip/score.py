import os
import json
import openai
import numpy as np
from openai import OpenAI

client = OpenAI(
    # 若没有配置环境变量，请用百炼API Key将下行替换为：api_key="sk-xxx",
    api_key="sk-24297ab9c2f9472bb17d17ec9e313021",
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

# 定义规则（系统提示）
system_prompt = """你是一个专业的交通评价分析师，你的任务是根据用户提供的微博内容，分析用户对于事物的正负面评价"""

# 定义情感评分函数
def get_sentiment_score(text):
    prompt = (
        f"请从交通评价的角度，分析下面的文本的情感极性，并输出一个-1到1之间的情感极性分数,不要解释。\n"
        f"文本：{text}\n"
        f"请直接返回数字，，不要额外说明。"
    )
    try:
        # 调用Qwen-Max模型进行情感分析（这里假设Qwen-Max是OpenAI兼容的模型）
        response = client.chat.completions.create(
            model="qwen-max",  # max>plus>turbo
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
        )
        sentiment_text = response.choices[0].message.content.strip()

        # 假设情感分数是-1到1之间的浮动
        sentiment_score = float(sentiment_text)

        return sentiment_score

    except Exception as e:
        print(f"Error analyzing sentiment: {e}")
        return 0.0  # 如果出错，返回默认情感分数0

# 定义评分函数
def get_score_from_sentiment(sentiment_score):
    if sentiment_score < -0.5:
        return 1  # 负面情感
    elif sentiment_score < 0:
        return 2  # 稍微负面
    elif sentiment_score < 0.5:
        return 3  # 中性
    elif sentiment_score < 0.8:
        return 4  # 稍微正面
    else:
        return 5  # 正面情感

# 获取分类结果文件夹中的类别文件
output_dir = 'classification_result'

# 预定义的九个类别
categories = ["安全性", "运行效率", "可靠性", "舒适性", "便捷性", "信息化与智能化", "经济性", "环境友好性","社会可持续性"]

# 存储九个类别的平均分
category_average_scores = {}

# 遍历每个类别
for category in categories:
    category_file_path = os.path.join(output_dir, f"{category}.json")

    if os.path.exists(category_file_path):
        with open(category_file_path, 'r', encoding='utf-8') as f:
            category_data = json.load(f)

        # 存储该类别下所有帖子的评分
        scores = []

        for item in category_data:
            text = item["text"]

            # 获取情感分数
            sentiment_score = get_sentiment_score(text)

            # 根据情感分数给出评分
            score = get_score_from_sentiment(sentiment_score)
            scores.append(score)

        # 计算该类别的平均分
        if scores:
            category_average = np.mean(scores)
            category_average_scores[category] = category_average
            print(f"类别 '{category}' 的平均分: {category_average:.2f}")

# 计算九个类别的整体平均分
overall_average_score = np.mean(list(category_average_scores.values()))
print(f"九个指标的整体平均分: {overall_average_score:.2f}")